/**
 * PATCH untuk GuestManagementPage.tsx
 *
 * HANYA ganti fungsi executeShareWhatsApp (sekitar baris 162-183).
 * Tidak ada perubahan lain yang diperlukan.
 *
 * Perubahan utama:
 * - Link pakai /welcome/:invitationId/:guestId agar CF Pages Function
 *   bisa intercept dan inject OG tags (termasuk og:image dengan QR code)
 * - Gunakan `invitationId` dari useParams() yang sudah ada di scope,
 *   bukan invitation.id (lebih aman karena invitationId pasti ada)
 */

// ─── SEBELUM (kode lama - HAPUS INI) ─────────────────────────────────────────
/*
const executeShareWhatsApp = async (guest: Guest) => {
    if (!invitation) return;
    const phone = guest.phone || '';
    const publicDomain = getPublicDomain();
    const personalLink = `https://${publicDomain}/${invitation.slug}/${guest.slug}`;
    const message = `${invitationMessage}\n\nLink Undangan: ${personalLink}`;
    window.open(`https://wa.me/${phone}?text=${encodeURIComponent(message)}`, '_blank');

    try {
        const now = new Date().toISOString();
        await guestsApi.update(guest.id, { shared_at: now });
        setGuests(prev => prev.map(g => g.id === guest.id ? { ...g, sharedAt: now } : g));
    } catch (error) {
        console.error('Failed to update share status:', error);
    }
    showToast('WhatsApp dibuka!');
    setShowShareModal(false);
};
*/

// ─── SESUDAH (kode baru - PAKAI INI) ─────────────────────────────────────────
const executeShareWhatsApp = async (guest: Guest) => {
    if (!invitation) return;
    const phone = guest.phone || '';

    // invitationId berasal dari useParams() - sudah ada di scope komponen
    // URL ini di-intercept oleh: functions/welcome/[invitationId]/[guestId].ts
    // yang inject og:image berisi QR code + nama + detail acara
    const personalLink = `${window.location.origin}/welcome/${invitationId}/${guest.id}`;

    const waLines = [
        invitationMessage,
        '',
        `📨 *Undangan untuk ${guest.name}*`,
        '',
        `🔗 Buka link undangan di bawah untuk lihat QR Code Anda:`,
        personalLink,
    ];

    const message = waLines.join('\n');

    window.open(
        `https://wa.me/${phone}?text=${encodeURIComponent(message)}`,
        '_blank'
    );

    // Mark as shared in DB (sama seperti sebelumnya)
    try {
        const now = new Date().toISOString();
        await guestsApi.update(guest.id, { shared_at: now });
        setGuests(prev => prev.map(g => g.id === guest.id ? { ...g, sharedAt: now } : g));
    } catch (error) {
        console.error('Failed to update share status:', error);
    }

    showToast('WhatsApp dibuka!');
    setShowShareModal(false);
};
