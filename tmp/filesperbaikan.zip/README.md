# Panduan Instalasi: OG Image + WhatsApp Share Preview

## Masalah yang Diselesaikan

WhatsApp crawler **tidak menjalankan JavaScript**. Karena `useSEO` bekerja
via JS, og:image tidak pernah terbaca oleh WA. Solusi ini menginject OG tags
langsung ke HTML di sisi server (Cloudflare Pages Functions).

---

## Struktur File yang Perlu Ditambah

```
tamuureact-main/
├── functions/                         ← BUAT FOLDER INI (di root project)
│   ├── welcome/
│   │   └── [invitationId]/
│   │       └── [guestId].ts          ← File 1: Middleware inject OG tags
│   └── api/
│       └── og-image.ts               ← File 2: Generate gambar preview
└── apps/
    └── web/
        └── src/
            └── pages/
                └── GuestManagementPage.tsx  ← File 3: Update 1 fungsi saja
```

---

## Langkah Instalasi

### 1. Buat folder `functions` di root project

```bash
mkdir -p functions/welcome/\[invitationId\]/\[guestId\]
mkdir -p functions/api
```

### 2. Copy file `[guestId].ts`

Copy ke: `functions/welcome/[invitationId]/[guestId].ts`

File ini intercept request ke `/welcome/:invitationId/:guestId`,
fetch data tamu dari `api.tamuu.id`, dan inject OG tags ke HTML.

### 3. Copy file `og-image.ts`

Copy ke: `functions/api/og-image.ts`

File ini generate SVG preview berisi:
- Background gradient gelap elegan
- Nama tamu (besar, serif)
- Nama acara, tanggal, venue
- QR Code (di-fetch dari qrserver.com, di-embed base64)

Test di browser: `https://app.tamuu.id/api/og-image?name=Ahmad&event=Pernikahan+Budi%26Sari&date=25+Jan+2026&venue=Gedung+Cirebon`

### 4. Update `GuestManagementPage.tsx`

Cari fungsi `executeShareWhatsApp` dan ganti dengan versi dari
`PATCH_executeShareWhatsApp.ts`.

**Perubahan inti:** Link yang dikirim ke WA sekarang pakai:
```
/welcome/${invitationId}/${guest.id}
```
Bukan lagi slug-based, agar Pages Function bisa intercept-nya.

---

## Cara Kerja Setelah Dipasang

```
User klik "Buka WhatsApp"
  → WA dapat link: https://app.tamuu.id/welcome/inv123/guest456
  
WA Crawler fetch link tersebut
  → Cloudflare Pages Function [guestId].ts intercept
  → Fetch data dari api.tamuu.id/api/guests/guest456
  → Inject <meta property="og:image" content="https://app.tamuu.id/api/og-image?...">
  → Return HTML dengan OG tags lengkap
  
WA fetch og:image URL
  → Cloudflare Pages Function og-image.ts
  → Fetch QR dari qrserver.com
  → Return SVG dengan nama tamu + QR code + detail acara
  
WA tampilkan preview card dengan gambar ✅
```

---

## Test

### Test OG image langsung:
```
https://app.tamuu.id/api/og-image?guestId=TEST&invitationId=TEST&name=Budi+Santoso&event=Pernikahan+Rizky%26Siti&date=25+Januari+2026&venue=Gedung+Graha+Cirebon
```

### Test OG tags di halaman welcome:
Buka di browser (view-source):
```
view-source:https://app.tamuu.id/welcome/[invitationId]/[guestId]
```
Cari `og:image` di source HTML — harus sudah ada sebelum `</head>`.

### Test preview WA:
Gunakan tool: https://www.opengraph.xyz
Masukkan URL: `https://app.tamuu.id/welcome/[invitationId]/[guestId]`

---

## Troubleshooting

**Q: Functions tidak jalan di Cloudflare Pages?**
A: Pastikan folder `functions/` ada di ROOT project (sejajar dengan `apps/`),
   bukan di dalam `apps/web/`. Cloudflare Pages auto-detect folder ini.

**Q: Invitation tidak ada field `id`?**
A: Cek response dari `invitationsApi.get()`. Jika field-nya berbeda (misal `invitation_id`),
   sesuaikan di `executeShareWhatsApp`:
   ```ts
   const personalLink = `${window.location.origin}/welcome/${invitationId}/${guest.id}`;
   // invitationId = dari useParams(), sudah ada di scope GuestManagementPage
   ```

**Q: QR code kosong?**
A: Kemungkinan rate limit qrserver.com. Coba akses URL test og-image langsung
   di browser - QR harus muncul. Jika tidak, cek network tab untuk error.

**Q: WA masih tidak tampil gambar?**
A: Verify:
   1. `view-source:` halaman welcome - pastikan og:image ada di HTML
   2. Test URL og-image langsung di browser - pastikan SVG tampil
   3. Gunakan opengraph.xyz untuk test - WA kadang cache preview lama
   4. WA bisa cache 24 jam, coba kirim ke nomor berbeda

---

## Catatan Keamanan

- File `[guestId].ts` hanya membaca data dari API (GET), tidak ada write
- Tidak ada auth token yang terekspos ke crawler
- Cache headers di-set 60 detik untuk halaman welcome, 1 jam untuk OG image
